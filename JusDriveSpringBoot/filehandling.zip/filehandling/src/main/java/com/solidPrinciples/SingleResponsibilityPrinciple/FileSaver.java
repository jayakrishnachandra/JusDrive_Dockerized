package com.solidPrinciples.SingleResponsibilityPrinciple;

import java.io.FileWriter;
import java.io.IOException;

public class FileSaver {
    public void save(String content) throws IOException {
        try (FileWriter writer = new FileWriter("report.txt")) {
            writer.write(content);
        }
    }
}
