package com.solidPrinciples.LiskovSubstitutionPrinciple;
public class Ostrich implements Bird {
    public void eat() {
        System.out.println("Ostrich eats plants.");
    }
}
