package com.reactiveProgramming;

import java.util.Scanner;
import java.util.concurrent.SubmissionPublisher;

public class ReactiveDemo {
    public static void main(String[] args) throws InterruptedException {
        SubmissionPublisher<String> publisher = new SubmissionPublisher<>();
        ReactiveSubscriber subscriber = new ReactiveSubscriber();

        publisher.subscribe(subscriber);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter messages to publish (type 'exit' to quit):");

        while (true) {
            String input = scanner.nextLine();
            if ("exit".equalsIgnoreCase(input)) {
                break;
            }
            publisher.submit(input);
        }

        scanner.close();
        publisher.close();
        Thread.sleep(1000); // Allow time for subscriber to process
    }
}
