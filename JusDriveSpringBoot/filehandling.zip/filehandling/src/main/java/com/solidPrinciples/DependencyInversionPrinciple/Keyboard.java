package com.solidPrinciples.DependencyInversionPrinciple;

public class Keyboard implements InputDevice {
    public String readInput() {
        return "Keyboard input";
    }
}