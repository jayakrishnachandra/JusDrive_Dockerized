package com.ByteOriented;

import java.io.*;

public class ReadingAndWritingUsingBuffer {
    public static void main(String[] args) {
        File src = new File("Hello.txt");
        File dest = new File("Hii.txt");

        try (FileInputStream srcStream = new FileInputStream(src);
             FileOutputStream destStream = new FileOutputStream(dest);
             BufferedInputStream bis = new BufferedInputStream(srcStream);
             BufferedOutputStream bos = new BufferedOutputStream(destStream)) {

            int temp;
            while ((temp = bis.read()) != -1) {
                bos.write(temp);
            }

            System.out.println("Successfully copied from src to dest");

            bos.close();

        } catch (FileNotFoundException e) {
            System.out.println("Error: Source file not found!");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("An error occurred while copying.");
            e.printStackTrace();
        }
    }
}
