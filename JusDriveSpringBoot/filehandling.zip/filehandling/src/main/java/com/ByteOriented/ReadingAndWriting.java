package com.ByteOriented;
import java.io.*;

public class ReadingAndWriting {
    public static void main(String[] args) throws FileNotFoundException {
        File src = new File("Hello.txt");
        File  dest = new File("Hii.txt");

        try
        {
            FileInputStream srcStream = new FileInputStream(src);
            FileOutputStream destStream = new FileOutputStream(dest);

            int temp;

            while ( (temp = srcStream.read()) !=-1)
            {
                destStream.write((byte) temp);
            }

            System.out.println("successfully copied form src to dest");


        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
