package com.solidPrinciples.InterfaceSegragationPrinciple;

public interface Printer {
    void print();
}
