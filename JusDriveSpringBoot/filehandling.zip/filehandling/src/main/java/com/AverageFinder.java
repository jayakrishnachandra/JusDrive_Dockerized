package com;

public class AverageFinder {
    public static void main(String[] args) {
        System.out.println("Average finder v0.1");
        double avg = findAverage(args);
        System.out.println("The average is " + avg);
    }

    private static double findAverage(String[] input) {
        double result = 0;
        for (String s : input) {
            result += Integer.parseInt(s);
        }
        return result;
    }
}

//If you define any other constructor (like parameterized ones), Java stops providing the default constructor.

class Person {
    String name;
//
    // Parameterized constructor
    public Person(String name) {
        this.name = name;
    }
}

// Compilation Error: No default constructor available!
//class Main {
//    public static void main(String[] args) {
//        Person p = new Person(); // ❌ Error: No default constructor exists!
//    }
//}
