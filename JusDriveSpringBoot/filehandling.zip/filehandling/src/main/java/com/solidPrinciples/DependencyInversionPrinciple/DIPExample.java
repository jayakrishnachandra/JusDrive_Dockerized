package com.solidPrinciples.DependencyInversionPrinciple;

public class DIPExample {
    public static void main(String[] args) {
        InputDevice keyboard = new Keyboard();
        InputDevice mouse = new Mouse();

        Computer comp1 = new Computer(keyboard);
        Computer comp2 = new Computer(mouse);

        comp1.receiveInput();
        comp2.receiveInput();
    }
}