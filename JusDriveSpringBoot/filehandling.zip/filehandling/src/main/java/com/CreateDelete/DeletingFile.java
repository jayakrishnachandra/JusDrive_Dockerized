package com.CreateDelete;

import java.io.File;

public class DeletingFile extends Object{

    public static void main(String[] args) {
        try
        {
            File obj = new File("Hello.txt");

            if(obj.delete())
            {
                System.out.println("deleted");
            }
        }

        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
