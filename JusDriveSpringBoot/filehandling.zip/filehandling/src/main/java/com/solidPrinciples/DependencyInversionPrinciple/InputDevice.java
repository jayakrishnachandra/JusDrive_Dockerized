package com.solidPrinciples.DependencyInversionPrinciple;

public interface InputDevice {
    String readInput();
}