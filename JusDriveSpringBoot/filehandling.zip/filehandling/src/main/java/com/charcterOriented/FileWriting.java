package com.charcterOriented;

import java.io.FileWriter;
import java.io.IOException;

public class FileWriting {

    public static void main(String[] args) throws IOException {
        try {
            FileWriter writer = new FileWriter("Hello.txt");
            writer.write("Hello world!");

            writer.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        }




    }
}
