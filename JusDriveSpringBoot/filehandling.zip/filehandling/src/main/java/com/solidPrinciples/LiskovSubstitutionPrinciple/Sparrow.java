package com.solidPrinciples.LiskovSubstitutionPrinciple;

public class Sparrow implements FlyingBird {
    public void eat() {
        System.out.println("Sparrow eats seeds.");
    }

    public void fly() {
        System.out.println("Sparrow flies.");
    }
}
