package com.charcterOriented;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ReadingFile {
    public static void main(String[] args) throws IOException {
        try
        {
            File obj = new File("Hello.txt");

// Approach 1

//            Scanner reader = new Scanner(obj);
//
//            while(reader.hasNext())
//            {
//                String data = reader.next();
//                System.out.print(data + " ");
//            }

//  Approach 2


            FileReader reader = new FileReader("Hello.txt");

            int temp;
            while((temp = reader.read()) !=-1)
            {
                System.out.print((char) temp);
            }
        }

        catch (IOException e)
        {
            System.out.println("File not found");
        }
    }
}
