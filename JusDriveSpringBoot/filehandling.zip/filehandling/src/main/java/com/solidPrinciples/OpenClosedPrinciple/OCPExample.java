package com.solidPrinciples.OpenClosedPrinciple;
import com.solidPrinciples.OpenClosedPrinciple.Shape;

public class OCPExample {
    public static void main(String[] args) {
        Shape circle = new Circle(5);
        Shape rectangle = new Rectangle(3,5);

        AreaCalc calc = new AreaCalc();


        System.out.println(calc.calculate(circle));
        System.out.println(calc.calculate(rectangle));
    }
}
