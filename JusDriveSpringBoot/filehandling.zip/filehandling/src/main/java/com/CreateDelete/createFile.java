package com.CreateDelete;

import java.io.File;
import java.io.IOException;

public class createFile {
    public static void main(String[] args) throws IOException {
        File obj = new File("hello.txt");  // Corrected filename syntax

        if(obj.createNewFile())
        {
            System.out.println("file created");
        }

        else {
            System.out.println("already exist");
        }
    }
}
