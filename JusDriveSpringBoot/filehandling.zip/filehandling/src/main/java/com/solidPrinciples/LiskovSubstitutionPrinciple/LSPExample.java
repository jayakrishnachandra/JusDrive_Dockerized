package com.solidPrinciples.LiskovSubstitutionPrinciple;

public class LSPExample {
    public static void main(String[] args) {
        Bird sparrow = new Sparrow();
        Bird ostrich = new Ostrich();

        sparrow.eat();
//        sparrow.fly();  // wont work sincle fly not available in bird
        ostrich.eat();

        FlyingBird flyer = new Sparrow();
        flyer.fly();
    }
}
