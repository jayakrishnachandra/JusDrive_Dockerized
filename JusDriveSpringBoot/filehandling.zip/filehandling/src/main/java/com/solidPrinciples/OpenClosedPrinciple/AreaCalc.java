package com.solidPrinciples.OpenClosedPrinciple;

import java.awt.*;

public class AreaCalc {
    public double calculate(Shape shape)
    {
        return  shape.area();
    }
}
