package com.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

// Define the annotation
@Retention(RetentionPolicy.RUNTIME) // Controls when annotation is available
@Target(ElementType.METHOD) // Specifies applicable elements (e.g., methods)
public @interface MyAnnotation {
    String value(); // Annotation attribute
}



class Example {

    @MyAnnotation(value = "Hello, Annotation!")
    public void myMethod() {
        System.out.println("Method executed.");
    }
}
