package com.solidPrinciples.LiskovSubstitutionPrinciple;

public interface FlyingBird extends Bird{
    void fly();
}
