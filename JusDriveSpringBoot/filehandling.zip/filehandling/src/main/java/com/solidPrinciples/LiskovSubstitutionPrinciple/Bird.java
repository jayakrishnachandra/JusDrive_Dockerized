package com.solidPrinciples.LiskovSubstitutionPrinciple;

public interface Bird {
    void eat();
}
