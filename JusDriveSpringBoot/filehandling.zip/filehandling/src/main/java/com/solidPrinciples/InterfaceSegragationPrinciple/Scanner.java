package com.solidPrinciples.InterfaceSegragationPrinciple;

public interface Scanner {
    void scan();
}
