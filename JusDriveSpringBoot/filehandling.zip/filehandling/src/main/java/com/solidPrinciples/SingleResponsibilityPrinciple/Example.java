package com.solidPrinciples.SingleResponsibilityPrinciple;

import java.io.IOException;

public class Example {
    public static void main(String[] args) {
        Report report = new Report();
        FileSaver saver = new FileSaver();
        try {
            saver.save(report.genrerate());
            System.out.println("saved");
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
