package com.solidPrinciples.InterfaceSegragationPrinciple;

public class ISPExample {
    public static void main(String[] args) {
        Printer printer = new BasicPrinter();

        printer.print();

        AdvancedPrinter advancedPrinter = new AdvancedPrinter();

        advancedPrinter.print();
        advancedPrinter.scan();



    }
}
