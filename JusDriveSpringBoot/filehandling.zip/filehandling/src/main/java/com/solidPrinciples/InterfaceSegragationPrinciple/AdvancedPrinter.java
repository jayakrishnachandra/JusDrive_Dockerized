package com.solidPrinciples.InterfaceSegragationPrinciple;

public class AdvancedPrinter implements Printer, Scanner {
    public void print()
    {
        System.out.println("printing document");
    }

    public void scan()
    {
        System.out.println("Scanning document");
    }
}
