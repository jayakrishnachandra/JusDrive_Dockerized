package com;

import java.util.HashMap;

public class CustomHashMap<K, V extends Employee> extends HashMap<K, V> {

    @Override
    public V put(K key, V value) {
        for (V employee : this.values()) {
            if (employee.equals(value)) {
                System.out.println("Duplicate field at :  " + key);
                return null;
            }
        }
        return super.put(key, value);
    }
}

//    @Override
//    public boolean equals(Object obj) {
//        if (this == obj)
//          {
//              return true;
//          }
//



















