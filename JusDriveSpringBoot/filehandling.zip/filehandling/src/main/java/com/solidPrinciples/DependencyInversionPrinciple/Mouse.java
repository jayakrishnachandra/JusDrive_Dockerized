package com.solidPrinciples.DependencyInversionPrinciple;

public class Mouse implements InputDevice {
    public String readInput() {
        return "Mouse input";
    }
}