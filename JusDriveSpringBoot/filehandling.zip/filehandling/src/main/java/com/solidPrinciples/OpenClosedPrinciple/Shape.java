package com.solidPrinciples.OpenClosedPrinciple;

public interface Shape {
    double area();
}
