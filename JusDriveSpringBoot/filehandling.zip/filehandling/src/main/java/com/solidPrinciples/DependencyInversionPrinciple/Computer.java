package com.solidPrinciples.DependencyInversionPrinciple;

public class Computer {
    private InputDevice device;

    public Computer(InputDevice device) {
        this.device = device;
    }

    public void receiveInput() {
        System.out.println("Received: " + device.readInput());
    }
}