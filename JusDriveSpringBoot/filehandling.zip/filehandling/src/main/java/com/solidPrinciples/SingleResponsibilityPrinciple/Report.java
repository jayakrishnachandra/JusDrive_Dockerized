package com.solidPrinciples.SingleResponsibilityPrinciple;

public class Report {
    public String genrerate()
    {
        return "Report content";
    }
}


