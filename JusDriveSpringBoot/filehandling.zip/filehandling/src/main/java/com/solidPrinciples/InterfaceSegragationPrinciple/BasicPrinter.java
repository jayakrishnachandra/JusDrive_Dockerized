package com.solidPrinciples.InterfaceSegragationPrinciple;

public class BasicPrinter implements Printer {
    public void print() {
        System.out.println("Printing document...");
    }
}
