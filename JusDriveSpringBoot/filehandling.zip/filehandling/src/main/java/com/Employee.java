package com;

public class Employee {
//    private int id;
    private String name;
    private int departmentId;
    private int salaryId;

    public Employee( String name, int departmentId, int salaryId) {
        this.name = name;
        this.departmentId = departmentId;
        this.salaryId = salaryId;
    }

    @Override
    public String toString() {
        return "Employee{" +
                ", name='" + name + '\'' +
                ", departmentId=" + departmentId +
                ", salaryId=" + salaryId +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;

        Employee employee = (Employee) obj;
        return salaryId == employee.salaryId || departmentId == employee.departmentId ;
    }

}
