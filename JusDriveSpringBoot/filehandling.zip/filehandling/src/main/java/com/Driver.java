package com;

import java.util.Map;

public class Driver {

    public static void main(String[] args) {

        Map<Integer, Employee> map = new CustomHashMap<>();
        Employee e1 = new Employee( "Jay", 2, 3);
        Employee e2 = new Employee( "Jay", 1, 4);
        Employee e3  = new Employee( "Jay", 5, 3);
        map.put(1, e1);
        map.put(2, e2);
        map.put(3, e3);

        System.out.println(map);

    }
}
